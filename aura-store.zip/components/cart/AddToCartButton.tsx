"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/Button";
import { useCartStore } from "@/lib/cart/store";
import type { ProductSummaryDto } from "@/lib/types/product";

/**
 * يضيف أول متغير متوفر إلى السلة — يُستخدم داخل بطاقة المنتج
 * حيث لا يوجد اختيار لون/مقاس. الاختيار الدقيق يتم في صفحة المنتج.
 */
export function AddToCartButton({ product }: { product: ProductSummaryDto }) {
  const addItem = useCartStore((state) => state.addItem);
  const [justAdded, setJustAdded] = useState(false);

  useEffect(() => {
    if (!justAdded) return;
    const timer = window.setTimeout(() => setJustAdded(false), 1600);
    return () => window.clearTimeout(timer);
  }, [justAdded]);

  const variant = product.variants.find((entry) => entry.inStock) ?? null;
  const isSoldOut = !variant;

  const handleClick = () => {
    if (!variant) return;

    addItem(
      {
        variantId: variant.id,
        productId: product.id,
        slug: product.slug,
        name: product.name.ar,
        variantLabel: variant.label,
        sku: variant.sku,
        unitPrice: Number(variant.price.amount),
        image: product.images[0]?.url ?? null,
        maxQuantity: variant.stockQuantity,
      },
      1,
    );

    setJustAdded(true);
  };

  return (
    <Button
      variant="outline"
      size="sm"
      fullWidth
      className="mt-4"
      disabled={isSoldOut}
      onClick={handleClick}
      aria-label={isSoldOut ? `${product.name} غير متوفر` : `إضافة ${product.name} إلى السلة`}
    >
      {isSoldOut ? "غير متوفر" : justAdded ? "تمت الإضافة ✓" : "أضف إلى السلة"}
    </Button>
  );
}
