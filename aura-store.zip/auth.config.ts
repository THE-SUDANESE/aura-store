import type { NextAuthConfig } from "next-auth";
import type { UserRole } from "@prisma/client";

/**
 * الإعداد المشترك بين الـ middleware (Edge) وخادم Node.
 * ممنوع هنا أي استيراد لـ Prisma أو bcrypt: الـ middleware يعمل على Edge runtime
 * ولا يستطيع تشغيل تلك المكتبات.
 *
 * الأدوار الإدارية المسموح لها بالوصول إلى /api/admin/*
 */
export const ADMIN_ROLES: readonly UserRole[] = ["owner", "store_admin"];

export const authConfig = {
  // في هذه النسخة لا نملك صفحة واجهة، لكن مسار الدخول محدد للاستخدام لاحقاً
  pages: { signIn: "/auth/login" },

  session: {
    // JWT: الجلسة تُقرأ من الكوكي المُوقّع بلا استعلام قاعدة بيانات في كل طلب
    strategy: "jwt",
    maxAge: 60 * 60 * 24 * 7, // 7 أيام
    updateAge: 60 * 60 * 24,  // يُعاد إصدار التوكن مرة يومياً
  },

  // مطلوب عند التشغيل خلف وكيل عكسي موثوق (Vercel / Nginx)
  trustHost: true,

  // يُستبدل في auth.ts بمزوّد Credentials (الذي يحتاج Node)
  providers: [],

  callbacks: {
    /**
     * يُنفَّذ عند إنشاء الجلسة وعند تحديثها.
     * ننسخ id و role إلى التوكن حتى لا نحتاج استعلاماً لكل طلب.
     */
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = user.role;
      }
      return token;
    },

    /** نقل الحقول من التوكن إلى كائن الجلسة المتاح للخادم والواجهة. */
    async session({ session, token }) {
      if (session.user && token.id && token.role) {
        session.user.id = token.id;
        session.user.role = token.role;
      }
      return session;
    },
  },
} satisfies NextAuthConfig;
