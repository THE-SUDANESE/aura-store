"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import type { FormEvent } from "react";
import { signIn } from "next-auth/react";
import { Button } from "@/components/ui/Button";

/**
 * صفحة دخول بسيطة (بريد + كلمة مرور) لحسابات الإدارة والعملاء.
 * التوجيه بعد النجاح إلى /admin؛ ومن لا يملك دوراً إدارياً يرى صفحة رفض واضحة هناك.
 */
export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (isSubmitting) return;

    setError(null);
    setIsSubmitting(true);

    try {
      const result = await signIn("credentials", {
        email: email.trim().toLowerCase(),
        password,
        redirect: false,
      });

      if (!result || result.error) {
        setError("البريد الإلكتروني أو كلمة المرور غير صحيحة.");
        return;
      }

      router.push("/admin");
      router.refresh();
    } catch {
      setError("تعذّر تسجيل الدخول. حاول مرة أخرى.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="shell flex min-h-[75vh] items-center justify-center py-16">
      <div className="w-full max-w-md rounded-4xl border border-ink-100 bg-white p-8 shadow-soft">
        <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-accent-700">
          AURA
        </p>
        <h1 className="mt-3 font-display text-2xl text-ink-900">تسجيل الدخول</h1>
        <p className="mt-2 text-xs text-ink-500">
          لحسابات الإدارة والعملاء. للشراء كزائر لا تحتاج إلى حساب.
        </p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
          <div>
            <label htmlFor="email" className="mb-1.5 block text-xs font-medium text-ink-700">
              البريد الإلكتروني
            </label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              required
              className="h-11 w-full rounded-xl border border-ink-200 bg-white px-3 text-sm text-ink-900 outline-none transition placeholder:text-ink-300 focus:border-ink-900 focus:ring-1 focus:ring-ink-900"
              placeholder="owner@aura.sa"
            />
          </div>

          <div>
            <label htmlFor="password" className="mb-1.5 block text-xs font-medium text-ink-700">
              كلمة المرور
            </label>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              required
              className="h-11 w-full rounded-xl border border-ink-200 bg-white px-3 text-sm text-ink-900 outline-none transition placeholder:text-ink-300 focus:border-ink-900 focus:ring-1 focus:ring-ink-900"
              placeholder="••••••••"
            />
          </div>

          {error && (
            <p
              role="alert"
              className="rounded-xl border border-warning-300 bg-warning-50 px-3 py-2 text-xs text-warning-700"
            >
              {error}
            </p>
          )}

          <Button type="submit" size="lg" fullWidth isLoading={isSubmitting}>
            دخول
          </Button>
        </form>

        <p className="mt-6 text-center text-[11px] text-ink-400">
          <Link href="/" className="underline underline-offset-4 hover:text-ink-700">
            العودة إلى المتجر
          </Link>
        </p>
      </div>
    </div>
  );
}
