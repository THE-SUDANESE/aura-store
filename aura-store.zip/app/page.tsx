import { Button } from "@/components/ui/Button";

const TRUST_ITEMS = [
  "شحن مجاني فوق ٣٠٠ ر.س",
  "إرجاع خلال ١٤ يوماً",
  "دفع عند الاستلام",
] as const;

export default function HomePage() {
  return (
    <>
      {/* ---------- الواجهة الترحيبية ---------- */}
      <section className="relative overflow-hidden border-b border-ink-100 bg-sand-100">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -left-24 top-1/2 h-72 w-72 -translate-y-1/2 rounded-full bg-accent-200/60 blur-3xl"
        />
        <div className="shell relative grid gap-10 py-16 sm:py-20 lg:grid-cols-[1.2fr_1fr] lg:items-center lg:py-28">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-accent-700">
              إصدار صيف ٢٠٢٦
            </p>
            <h1 className="mt-5 font-display text-4xl leading-[1.15] text-ink-900 sm:text-5xl lg:text-6xl">
              نظّارة تُرى قبل أن تُسمع.
            </h1>
            <p className="mt-6 max-w-lg text-base leading-8 text-ink-600">
              نظارات شمسية وأزياء مختارة بعناية، بعدسات تحجب ١٠٠٪ من الأشعة فوق البنفسجية،
              وتفاصيل تصنع الفرق. تصميم هادئ — حضور لا يُنسى.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-3">
              <Button variant="primary" size="lg">
                تسوّق النظارات
              </Button>
              <Button variant="outline" size="lg">
                اكتشف الأزياء
              </Button>
            </div>

            <ul className="mt-10 flex flex-wrap gap-x-6 gap-y-2 text-xs text-ink-600">
              {TRUST_ITEMS.map((item) => (
                <li key={item} className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-accent-500" aria-hidden="true" />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          {/* بطاقة بصرية مؤقتة (بديل غلاف المجموعة) */}
          <div className="relative mx-auto aspect-[4/5] w-full max-w-sm rounded-4xl border border-ink-200/70 bg-gradient-to-br from-ink-900 via-ink-800 to-ink-950 p-8 shadow-soft">
            <span className="text-[11px] uppercase tracking-[0.3em] text-sand-200/70">AURA</span>
            <p className="mt-6 font-display text-3xl leading-snug text-white">
              ضوء أقل.
              <br />
              حضور أكثر.
            </p>
            <p className="mt-4 max-w-[15rem] text-sm leading-7 text-ink-300">
              عدسات مستقطبة، إطارات خفيفة، وحماية UV400 كاملة.
            </p>
            <span className="absolute bottom-8 start-8 text-sm text-white/80">٢٤ منتجاً جديداً</span>
          </div>
        </div>
      </section>

      {/* ---------- معرض مكوّن الزر (مرجع بصري للمطورين) ---------- */}
      <section className="shell py-16">
        <div className="flex flex-wrap items-end justify-between gap-4 border-b border-ink-100 pb-5">
          <div>
            <h2 className="text-xl font-semibold text-ink-900">مكوّن الزر — الحالات والأحجام</h2>
            <p className="mt-2 text-sm text-ink-500">
              مرجع سريع للمكوّن <code className="rounded bg-ink-100 px-1.5 py-0.5 text-xs">components/ui/Button.tsx</code>
            </p>
          </div>
          <span className="rounded-full bg-warning-100 px-3 py-1 text-xs text-warning-700">
            صفحة مؤقتة للعرض البصري
          </span>
        </div>

        <div className="mt-10 grid gap-10 lg:grid-cols-2">
          <div>
            <h3 className="text-sm font-semibold text-ink-800">الأنماط (Variants)</h3>
            <div className="mt-4 flex flex-wrap items-center gap-3 rounded-2xl border border-ink-100 bg-white p-5 shadow-card">
              <Button variant="primary">أساسي</Button>
              <Button variant="secondary">ثانوي جريء</Button>
              <Button variant="outline">محدّد</Button>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-ink-800">الأحجام (Sizes)</h3>
            <div className="mt-4 flex flex-wrap items-center gap-3 rounded-2xl border border-ink-100 bg-white p-5 shadow-card">
              <Button size="sm">صغير</Button>
              <Button size="md">متوسط</Button>
              <Button size="lg">كبير</Button>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-ink-800">الحالات (States)</h3>
            <div className="mt-4 flex flex-wrap items-center gap-3 rounded-2xl border border-ink-100 bg-white p-5 shadow-card">
              <Button disabled>معطّل</Button>
              <Button isLoading>جارٍ الإضافة</Button>
              <Button variant="secondary" size="sm">
                عرض سريع
              </Button>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-ink-800">عرض كامل (Full width)</h3>
            <div className="mt-4 space-y-3 rounded-2xl border border-ink-100 bg-white p-5 shadow-card">
              <Button fullWidth>أضف إلى السلة</Button>
              <Button variant="outline" fullWidth>
                شراء سريع
              </Button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
