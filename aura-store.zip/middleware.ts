import NextAuth from "next-auth";
import type { NextRequest } from "next/server";
import { ADMIN_ROLES, authConfig } from "./auth.config";
import { fail } from "@/lib/http";

/**
 * حماية مسارات الإدارة على مستوى الـ middleware.
 *
 * مهم: هذا الحاجز الأول فقط (سريع، بلا قاعدة بيانات) — وكل مسار إداري
 * يجب أن يستدعي requireAdmin() أيضاً، لأن الـ middleware وحده
 * لا يكفي كطبقة تصريح (راجع توثيق Auth.js نفسه).
 */
const { auth } = NextAuth(authConfig);

function requestIdOf(req: NextRequest): string {
  // crypto المتاح على Edge runtime (لا نستخدم node:crypto هنا)
  return req.headers.get("x-request-id") ?? crypto.randomUUID();
}

export default auth((req) => {
  const requestId = requestIdOf(req);
  const user = req.auth?.user;

  if (!user?.id) {
    return fail("UNAUTHORIZED", "يجب تسجيل الدخول للوصول إلى هذه الواجهة.", 401, requestId);
  }

  if (!ADMIN_ROLES.includes(user.role)) {
    return fail("FORBIDDEN", "هذا الحساب لا يملك صلاحية إدارية.", 403, requestId);
  }

  // مسموح: نكمل إلى معالج المسار
  return undefined;
});

export const config = {
  // يشمل كل ما تحت /api/admin (بما فيها المسارات المتداخلة)
  matcher: ["/api/admin/:path*"],
};
